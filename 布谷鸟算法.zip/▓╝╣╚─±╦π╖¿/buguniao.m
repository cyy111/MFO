% ����f(x)=��ni=1 xi2,(?20��x��20��n=10)��Сֵ
% https://blog.csdn.net/zyqblog/article/details/80905019
% Script �������㷨����⺯����Сֵ
% @author zhaoyuqiang 
%#ok<*SAGROW> Remove hints of syntax
%#ok<*CLALL>
%#ok<*FNDSB>
clear all ; 
close all ;
clc ;
N = 25; %��Number of nests(The scale of solution)
D = 10 ; %  Dimensionality of solution
T = 200 ; % Number of iterations
Xmax = 20 ;
Xmin = -20 ;
Pa = 0.25 ; % Probability of building a new nest(After host bird find exotic bird eggs)
nestPop = rand(N,D)*(Xmax-Xmin)+Xmin ;  % Random initial solutions
for t=1:T
    levy_nestPop =  func_levy(nestPop,Xmax,Xmin) ; % Generate new solutions by Levy flights
    nestPop = func_bestNestPop(nestPop,levy_nestPop);  % Choose a best nest among  new and old nests     
    rand_nestPop = func_newBuildNest(nestPop,Pa,Xmax,Xmin); % Abandon(Pa) worse nests and build new nests by (Preference random walk )
    nestPop = func_bestNestPop(nestPop,rand_nestPop) ; % Choose a best nest among  new and old nests
    [~,index] = max(func_fitness(nestPop)) ; % Best nests
    trace(t) = func_objValue(nestPop(index,:)) ; 
end

figure 
plot(trace);
xlabel('��������') ;
ylabel('��Ӧ��ֵ') ;
title('��Ӧ�Ƚ�������') ;


